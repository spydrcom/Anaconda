# -*- coding: utf-8 -*-
"""
Created on Sat Aug 14 18:45:18 2021
Methods that provide socket services for eval processing
@author: Michael Druckman
"""


# trace flags

tracing_accept  = 0
tracing_request = 1


# name of server hosting SitStat

SITSTAT_PREFERED_PORT = 8000
SITSTAT_HOST = "LOCALHOST"


# configure constants for server

STANDARD_BUFFER_SIZE = 4096 # space allocated for response reads
COUNT_OF_INSTANCES = 5      # number of parallel processing instances


# count of requests processed

Traffic_seen = 0


# server request constants

STOP_REQUEST = "STOP"
STATUS_REQUEST = "?"
TRACE_REQUEST = "!"

TRACE_ADDR = "!ADDR"
TRACE_EVAL = "!EVAL"


# symbol imports for networking implementation

import socket
from socket import SOCK_STREAM
from socket import AF_INET


# create a new socket

def create_socket ():

    # boiler-plate socket creation for bind / listen
    return socket ( AF_INET, SOCK_STREAM )


# open communication to specified port
# - identity of host by name or address
# - port number on the specified host
# : return the created socket

def connect (host, port):

    new_socket = create_socket ()
    new_socket.connect (  (host, port)  )

    return new_socket


# produce port service support
# - port the port to listen for requests
# - the number of instances for parallel processing
# : the socket bound to the service

def bind_and_listen (port, instances):

    # create socket / bind / listen
    bound_socket = create_socket ()
    bound_socket.bind ( ( '', port ) )
    bound_socket.listen ( instances )

    return bound_socket


# encode content to utf-8 and send to client
# - socket object being used for client communication
# - text of content being sent to client

def send_encoded (client, content):

     # encode response as utf-8 before sending
     encd_response = content.encode ('utf-8')

     # send response to client over socket
     client.send (encd_response)
     return


# encode content to utf-8, send to client, and close connection
# - socket object being used for communication to client
# - text of response message being sent to client

def send_response (client, response):

     send_encoded (client, response)
     client.close ()
     return


# send request and read returned response
# - socket object being used for communication to client
# - text of response message being sent to client
# : the buffer containing the response read

def handshake (client, source, buffer_size):
    
    # encode the request to utf-8 to be sent
    send_encoded (client, source)
    
    # read the response into a byte buffer 
    byte_buffer = client.recv ( buffer_size )
    
    # decode the response in the buffer to utf-8
    response_buffer = byte_buffer.decode ('utf-8')

    # close the client connection
    client.close ()
    
    return response_buffer


# send a confirmation to the requester
# - the requesting connection to the client

def respond_to_stop_request (client):

    # respond with confirmation
    send_response (client, 'Stopping...')
    raise RuntimeError ('STOP requested')


# send response to request for traffic
# - the connection object to use for communication
# - the value computed as the number of processed requests

def respond_to_traffic_request (client, trafic):

    # respond with the count of requests processed
    traffic_response = '{:d}'.format(trafic)
    send_response (client, traffic_response)
    return


# toggle flag value
# - the original flag value

def toggle(flag):
    
    if flag == 0: return 1
    else: return 0


# send response to request for trace
# - the connection object to use for communication
# - the text of the request

def respond_to_trace_request (client, request):

    global tracing_accept
    global tracing_request

    # respond with confirmation
    response = "Trace not recognized"

    if request.startswith (TRACE_ADDR):

        # source address trace
        tracing_accept = toggle (tracing_accept)
        response = "OK"

    elif request.startswith (TRACE_EVAL):

        # trace expression being evaluated
        tracing_request = toggle (tracing_request)
        response = "OK"

    send_response (client, response)
    return


# accept socket request and pass to processor
# - socket object idnetified by caller (must be boud to port)
# - buffer size to be used to receive response text returned by socket
# - a processor to apply to the request, must accept string and return string

def serve_request (socket_served, buffer_size, request_processor):

    global Traffic_seen
    last_seen = Traffic_seen

    # accept socket connection and recv request
    client, calling_addr = socket_served.accept ()
    request_recd = client.recv ( buffer_size )
    req_string = request_recd.decode ('utf-8')

    # trace lines for accept and request traces
    if tracing_accept: print ('Request accepted from ', calling_addr)
    if tracing_request: print (req_string)

    # process requests

    if req_string.startswith (STOP_REQUEST):

        # respond to STOP request, end processing
        respond_to_stop_request (client)

    elif req_string.startswith (TRACE_REQUEST):
        
        # respond with confirmation
        respond_to_trace_request (client, req_string)
        
    elif req_string.startswith (STATUS_REQUEST):
        
        # respond with traffic number
        respond_to_traffic_request (client, last_seen)

    else:

        # process request and encode response for sending
        response = request_processor (req_string)

        # send response and closee connection
        send_response (client, response)

    # update traffic to reflect request
    Traffic_seen = last_seen + 1

    return


# idetify request processor as Python eval function
# - socket object idnetified by caller (must be boud to port)
# - return the text resulting from the serve_request method call

def serve_eval_request (socket_used):

    # simple service test with default parameters
    serve_request (socket_used, STANDARD_BUFFER_SIZE, lambda x: eval (x) )
    return


# loop until exception is raised
# - socket object idnetified by caller (must be bound to port)
# - STOP command raises RuntimeError and all errors end service loop

def serve_eval_until_stop (socket_used):

    # acknolege swervice start of execution
    print ('Service loop is starting')

    global Traffic_seen
    Traffic_seen = 0
    
    # loop until an exception is raised

    try:
        while 1:         # looping forever
            serve_eval_request (socket_used)
    except Exception as exception_seen: 
        # acknolege exception processing
        print (exception_seen)

    # acknolege swervice termination of execution
    print ('Service loop has terminated')

    # close connection when done
    socket_used.close()

    return


# identify standard port as 8080

def serve_eval_8080 ():

    # default service start on port 8080
	serve_eval_on (8080, COUNT_OF_INSTANCES)
	return


# construct socket and start to listen
# - port number to listen on (common use is HTTP ports)
# - number of threads to run in parallel listening on port

def serve_eval_on (port, instances):

    # boiler-plate socket creation for bind/listen
    bound_socket = bind_and_listen (port, instances)

    # start server loop listening on bound_socket
    serve_eval_until_stop (bound_socket)
    return bound_socket


# original source of send/receive of encoded text
# - text of request to pass over socket to the server
# - host name and port number for the socket connection
# - buffer size to be used to receive response text returned by socket

def request_eval (source, host, port, buffer_size):
    
    # send encoded request
    socket_used = connect (host, port)
    
    # request / response handshake to process the source
    return handshake (socket_used, source, buffer_size)


# use SitStat to assign port
# - source of request to be used

def request_assignment (request):
    
    return request_eval ( request,
         SITSTAT_HOST, SITSTAT_PREFERED_PORT,
         STANDARD_BUFFER_SIZE
    )


# construct and send a STOP request
# - host name and port number for the socket connection

def request_stop (host, port):
    
    # STOP request is reconized as termination request
    send_response ( connect (host, port), STOP_REQUEST )
    return


# start EVAL service using assigned configuration
# - text returned from assignment request

def post_eval_as_assigned (port_id):

    # start EVAL service on assigned port
    print("EVAL service posted on port ", port_id)
    serve_eval_on ( int (port_id), COUNT_OF_INSTANCES )
    return


# post EVAL service to SitStat server

def post_eval_locally ():

    request = "POST EVAL 8080\n"
    # assume SitStat server is running on 8000
    # request for assignment to port 8080 for EVAL service
    response = request_assignment ( request )

    # error check
    responses = response.split ()
    if ( responses[0] != "POSTED" ):
        print ( "Error in post request processing" )
        print ( response )
        return

    # get returned port
    port_number = responses[1]
    # configure service to use assignment
    post_eval_as_assigned (port_number)
    return

