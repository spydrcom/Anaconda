# -*- coding: utf-8 -*-
"""
Created on Sat Aug 14 18:45:18 2021
Methods that provide domain production for evaluation
@author: Michael Druckman
"""

import io
import json

# domain construction on complex starting point and complex delta
# - P is the starting point intended to be a complex value (but would work generically)
# - delta is the difference between each pair of adjacent values
# - returned result is an array of values

def domain (p, delta, count):
    # construct domain from point and delta*count
	x = [ p + i * delta for i in range ( 0, count ) ]
	return x

# construct a domain represented as an array of complex values
# - P is the starting point passed in as [pr,pi] float which combine as complex
# - delta is the difference between each pair of adjacent values, again [deltar,deltai]
# - count is an integer presenting the number of points requested
# - returned result is an array of values

def cdomain (pr, pi, deltar, deltai, count):
    # P and delta are converted to complex values
    x = domain ( complex(pr,pi), complex(deltar,deltai), count )
    return x

# build domain and evaluate function at each point
#  (results from this run will be array of complex)
# - parameters [pr,pi] and [dr,di] match cdomain
# - returned result is an array of values

def runF (f, pr, pi, dr, di, count):
    # domain is built and n-tuple is made from iterator
    x = cdomain ( pr, pi, dr, di, count )   # construct domain vector
    y = [ getFhndld (f, z) for z in x ]     # array of function evaluations 
    return y

# all results are complex but treat as Python float tuples
#  (this is done to avoid syntax treatment on disparate systems)
# NOTE: JSON has no syntax for the representation of complex values
# - returned result is a JSON array of float tuples

def getFtuples (f, pr, pi, dr, di, count):
    # function is called for each domain value
    y = runF (f, pr, pi, dr, di, count)
    # complex values are split into re/im tuples
    tups = [ (float(a.real),float(a.imag)) for a in y ]
    # JSON text is formatted to represent value list
    sbuf = io.StringIO ()       # a strng buffer to collect JSON
    json.dump ( tups, sbuf )    # the tuples array converted to JSON
    return sbuf.getvalue ()     # return the buffer contents

# call function to evaluate at x and trap error conditions
# - returned result is a single value which will match the function returned value
# - error conditions will cause the returned value to be complex(9E99,9E99)

def getFhndld (f, x):
	try:                        # catch exceptions thrown by EVAL call
		y = f(x)                # each call to funtion could cause raise
	except:
		y = complex(9E99,9E99)  # 9E99 will be recognized as invalid
	return y;                   # return a value as a function result
