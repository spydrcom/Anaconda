# -*- coding: utf-8 -*-
"""
Created on Sat Aug 14 18:45:18 2021
Methods that provide domain production for evaluation
@author: Michael Druckman
"""

import io
import json

def domain (p, delta, count):
    # construct domain from point and delta*count
	x = [ p + i * delta for i in range ( 0, count ) ]
	return x

def cdomain (pr, pi, deltar, deltai, count):
    # P and delta are converted to complex values
    x = domain ( complex(pr,pi), complex(deltar,deltai), count )
    return x

def runF (f, pr, pi, dr, di, count):
    # domain is built and n-tuple is made from iterator
    x = cdomain (pr, pi, dr, di, count)
    y = [ getFhndld(f,z) for z in x ]
    return y

def getFtuples (f, pr, pi, dr, di, count):
    # function is called for each domain value
    y = runF (f, pr, pi, dr, di, count)
    # complex values are split into re/im tuples
    tups = [ (float(a.real),float(a.imag)) for a in y ]
    # JSON text is formatted to represent value list
    sbuf = io.StringIO ()
    json.dump (tups,sbuf)
    return sbuf.getvalue()

def getFhndld (f, x):
	try:                        # catch exceptions thrown by EVAL call
		y = f(x)                # each call to funtion could cause raise
	except:
		y = complex(9E99,9E99)  # 9E99 will be recognized as invalid
	return y;                   # return a value as a function result
