# -*- coding: utf-8 -*-
"""
Created on Sat Aug 14 18:45:18 2021
Methods that provide socket services for eval processing
@author: Michael Druckman
"""

tracing_accept  = 0
tracing_request = 1

# symbol imports for networking implementation

import socket
from socket import SOCK_STREAM
from socket import AF_INET

def serve_request (socket_served, buffer_size, request_processor):
     # accept socket connection and recv request
     client, addr = socket_served.accept ()
     request_recd = client.recv ( buffer_size )
     req_string = request_recd.decode ('utf-8')
     if tracing_accept: print ('Request accepted from ', addr)
     if tracing_request: print (req_string)
     # check for STOP request and raise if found
     if req_string.startswith('STOP'):
         message = b'Stopping...'
         client.send (message)
         raise RuntimeError ('STOP requested')
     # process request and encode response for sending
     rsp_string = request_processor (req_string)
     encd_response = rsp_string.encode ('utf-8')
     # send response and closee connection
     client.send ( encd_response )
     client.close ()
     return
 
def serve_eval_request (socket_used):
    # simple service test with default parameters
    return serve_request (socket_used, 4096, lambda x: eval (x) )

def serve_eval_until_stop (socket_used):
    # loop until an exception is raised
    try:
        while 1:         # looping forever
            serve_eval_request (socket_used)
    except:         # close connection when done
        socket_used.close()

def serve_eval_8080 ():
    # default service start on port 8080
	serve_eval_on (8080, 5)
	return

def serve_eval_on (port, instances):
    # boiler-plate socket creation for bind/listen
	bound_socket = socket ( AF_INET, SOCK_STREAM )
	bound_socket.bind ( ('',port) )
	bound_socket.listen (instances)
    # start server loop listening on bound_socket
	serve_eval_until_stop (bound_socket)

def request_eval (source, host, port, buffer_size):
    # send encoded request / decode response from server
    socket_used = socket ( AF_INET, SOCK_STREAM )
    socket_used.connect ( (host,port) )
    coded_request = source.encode ('utf-8')
    socket_used.send ( coded_request )
    byte_buffer = socket_used.recv ( buffer_size )
    response_buffer = byte_buffer.decode ('utf-8')
    socket_used.close ()
    return response_buffer

def request_stop (host, port):
    # STOP request is reconized as termination request
    socket_used = socket ( AF_INET, SOCK_STREAM )
    socket_used.connect ( (host,port) )
    coded_request = b'STOP'
    socket_used.send ( coded_request )
    socket_used.close ()
    return
