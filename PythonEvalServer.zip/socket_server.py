# -*- coding: utf-8 -*-
"""
Created on Sun Aug 15 09:31:42 2021
Start services for EVAL requests coming over TCP sockets
@author: Michael Druckman
"""

tracing_request = 0

# import code references for interface implementations

from socket import *
import json
import io

# import library symbols for EVAL

import scipy
import mpmath

# start EVAL service

serve_eval_8080 ()

# will loop until STOP is seen
